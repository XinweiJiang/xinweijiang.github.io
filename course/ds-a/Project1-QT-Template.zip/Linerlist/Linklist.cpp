#include "Linklist.h"
template class Linklist<int>;//模板显式实例化
/*
使用的模板类后，函数实现需与类同源。若将函数实现直接置于相应的cpp文件中，将出现编译错误。
可以通过使用export关键字和模板显式实例化解决这一问题。
因为Qt不支持export关键字，所以在本代码中使用的是模板显式实例化。
*/
template <class T>
Linklist<T>::Linklist() {
    //write your code here：实现构造函数

}

template<class T>
Linklist<T>::~Linklist() {
    //write your code here：实现析构函数

}

template<class T>
bool Linklist<T>::Insert(T x, T y) {
    //write your code here：在值为x的元素后插入一个值为y的元素

return true;
}

template<class T>
bool Linklist<T>::Remove(T x) {
    //write your code here：删除值为x的节点，务必delete释放内存

return true;
}

template<class T>
void Linklist<T>::Reverse() {
    //write your code here：逆置list

}
template<class T>
void Linklist<T>::Insert_last(T &x) {
       //write your code here：在list的末尾添加一个值为x的节点,尾插为构造表的必需函数

}
template<class T>
int Linklist<T>::Size() {
    return size;
}
template<class T>
Linknode<T> *Linklist<T>::Begin() {
    return begin->next;
}
