### 运行环境

Win 10/11

Qt 5.14.2 MinGw 32-bit

Qt 5.14.2 MinGw 64-bit

-------

### 说明

\color{red}{**模版中的函数名等信息已修改，请以代码中的注释为准，以下说明和截图仅供参考**}

请按照模板所给定义实现单链表和顺序表，将相应函数置于Seqlist.h 和linklist.h中


模板中， 类list (list.h)为Seqlist (Seqlist.h)和Linklis (linklist.h)类的基类。三种类的具体定义见代码。图中为Linklist的声明。

<img src="D:\Qt project\Linerlist\image-20220926160536082.png" alt="image-20220926160536082" style="zoom:67%;" />

代码中，注释所指出的部分请按照所给定义来实现，否则程序可能无法正常运行。

注意，c++中模板类（使用了template的类）声明与实现必须是同源的。若函数实现直接置于cpp文件中，将出现编译错误。该问题可以通过`export`关键字或模板显式实例化解决。因为Qt不支持export关键字，故在该代码中使用了模板显式实例化。具体请见Seqlist.cpp和linklist.cpp。

#### UI说明

##### 主窗体(mainwindow.h)

主窗口为类MainWindow，对应文件mainwindow.h 。如图所示，主窗口包含共包含四个控件。

<img src="\image-20220921213439693.png" alt="image-20220921213439693" style="zoom: 67%;" />

控件1~3均为`QPushButton`类，分别对应对象 `btn_info` , `btn_seq` , `btn_link`，用于实现对控件4窗体切换的控制。

控件4为`QStackedWidget` ，对应对象`CenteralWidget`，该控件中包含三个窗体`wid_info` , `wid_seq `, `wid_link`。

##### 测试信息窗体(infowidget.h)

测试信息窗体为类InfoWidget，也既上图控件4中显示的窗体。包含数个QLabel控件，用于显示对应信息。

在该类中，将对顺序表和链表进行复杂度测试，运行时间过长的部分将用红色标出，顺序表和链表的各功能算法时间复杂度都不应超过$O(n)$。

上图中，循序表多插为$O(n^2)$。

##### 顺序表窗体(seqwidget.h)

对应的类为SeqWidget，共包含9个控件。

<img src="\image-20220921221216820.png" alt="image-20220921221216820" style="zoom:67%;" />

控件1为QLabel类，用于显示信息。

控件2为QListWidgett类，对应对象`widget`用于显示顺序表中对应的元素。

控件3~9为QPushButton类，对应顺序表的各个函数功能，分别对应对象：
`btn_creat` , `btn_push btn_Ins_multiple` , `btn_Ins_wanted` , `btn_Del_multiple` , `btn_Del_wanted`,`btn_reverse`

上述按键控件在点击后将调用顺序表对应的函数，并调用函数`refresh()`刷新控件2`widget`中的内容。若有需要输入的数据，则弹出QDialog对话框，显示相应信息要求用户键入数据。

##### 链表窗体(linkwidget.h)

与顺序表窗体类似，不再赘述。



### Hint

为保证程序的正常运行，请严格按照Seqlist.h和linklist.h中所给的声明实现顺序表和链表！！