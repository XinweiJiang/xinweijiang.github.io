#include "Seqlist.h"
template class Seqlist<int>;//模板显式实例化
/*
使用的模板类后，函数实现需与类同源。若将函数实现直接置于相应的cpp文件中，将出现编译错误。
可以通过使用export关键字和模板显式实例化解决这一问题。
因为Qt不支持export关键字，所以在本代码中使用的是模板显式实例化。
*/
template <class T>
void Seqlist<T>::extend() {
    T *tmp = new T[maxsize *= 2];
    for (int i = 0; i < last; i++) tmp[i] = data[i];
    delete data;
    data = tmp;
    tmp = nullptr;
}

template<class T>
Seqlist<T>::Seqlist() {
    //write your code here：实现构造函数

}

template<class T>
Seqlist<T>::Seqlist(int x) {
    //write your code here：实现析构函数

}

template<class T>
bool Seqlist<T>::Insert(T x, T y) {
    //write your code here：在值为x的元素后插入一个值为y的元素

return true;
}

template<class T>
bool Seqlist<T>::Remove(T x) {
    //write your code here：删除值为x的节点，务必delete释放内存
    return true;

}

template<class T>
void Seqlist<T>::Insert_last(T &x) {
    //write your code here：在list的末尾添加一个值为x的元素,尾插为构造表的必需函数

}

template<class T>
void Seqlist<T>::Reverse() {
    //write your code here：逆置list

}

template<class T>
int Seqlist<T>::Size() {
    return last;
}

template<class T>
int Seqlist<T>::Capacity() {
    return maxsize;
}

template<class T>
T* Seqlist<T>::Begin() {
    return data;
}

template<class T>
T& Seqlist<T>::operator[](int x) {
    if (x >= last) return data[last - 1];
    if (x < 0) return data[0];
    return data[x];
}


