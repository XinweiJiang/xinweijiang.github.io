#include "Seqlist.h"
template class Seqlist<int>;//模板显式实例化
/*
使用的模板类后，函数实现需与类同源。若将函数实现直接置于相应的cpp文件中，将出现编译错误。
可以通过使用export关键字和模板显式实例化解决这一问题。
因为Qt不支持export关键字，所以在本代码中使用的是模板显式实例化。
*/
template <class T>
void Seqlist<T>::extend() {
    T *tmp = new T[cap *= 2];
    for (int i = 0; i < siz; i++) tmp[i] = arr[i];
    delete arr;
    arr = tmp;
    tmp = nullptr;
}

template<class T>
Seqlist<T>::Seqlist() {
    //write your code here：实现构造函数
}

template<class T>
Seqlist<T>::Seqlist(int x) {
    //write your code here：实现析构函数
}

template<class T>
bool Seqlist<T>::Insert(T &x, T &y, bool bFlag) {
    //write your code here：在值为x的元素后插入一个值为y的元素（bFlag=0单插,bFlag=1多插）
}

template<class T>
bool Seqlist<T>::Remove(T &x, bool bFlag) {
    //write your code here：删除值为x的节点，务必delete释放内存（bFlag=0单删,bFlag=1多删）
}

template<class T>
void Seqlist<T>::Insert_last(T& x) {
    //write your code here：在list的末尾添加一个值为x的元素
}

template<class T>
void Seqlist<T>::Reverse() {
    //write your code here：逆置list
}

template<class T>
int Seqlist<T>::Size() {
    return size;
}

template<class T>
int Seqlist<T>::Capacity() {
    return cap;
}

template<class T>
T* Seqlist<T>::Begin() {
    return arr;
}

template<class T>
T& Seqlist<T>::operator[](int x) {
    if (x >= size) return arr[size - 1];
    if (x < 0) return arr[0];
    return arr[x];
}


