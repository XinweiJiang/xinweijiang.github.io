#include "seqwidget.h"

SeqWidget::SeqWidget(QWidget *parent) : QWidget(parent)
{
    title = new QLabel(this);
    title->setText("顺序表");
    title->setFont(QFont( "Microsoft YaHei", 15, 60));
    resize(400, 450);
    widget = new QListWidget(this);
    widget->resize(300, height() - 10);
    widget->move(0, 30);

    btn_creat = new QPushButton(this); btn_creat->setText("创建表");
    btn_creat->move(310, 10); btn_creat->resize(180, 40);

    btn_push = new QPushButton(this); btn_push->setText("添加元素");
    btn_push->move(310, 60); btn_push->resize(180, 40);

    btn_Ins_multiple = new QPushButton(this); btn_Ins_multiple->setText("在指定数据后插入元素");
    btn_Ins_multiple->move(310, 110); btn_Ins_multiple->resize(180, 40);

    btn_Ins_wanted = new QPushButton(this); btn_Ins_wanted->setText("在指定元素后插入元素");
    btn_Ins_wanted->move(310, 160); btn_Ins_wanted->resize(180, 40);

    btn_Del_multiple = new QPushButton(this); btn_Del_multiple->setText("删除所有指定值元素");
    btn_Del_multiple->move(310, 210); btn_Del_multiple->resize(180, 40);

    btn_Del_wanted = new QPushButton(this); btn_Del_wanted->setText("删除选定元素");
    btn_Del_wanted->move(310, 260); btn_Del_wanted->resize(180, 40);

    btn_reverse = new QPushButton(this); btn_reverse->setText("元素逆置");
    btn_reverse->move(310, 310); btn_reverse->resize(180, 40);
    connects();
}

void SeqWidget::setDia(QDialog *dia, QLabel *lab, QPushButton *check, QLineEdit *edit, QString s_lab, QString title) {
    lab->resize(400, 30);
    lab->setText(s_lab);

    check->setText("确定"); check->move(85, 80); check->resize(80, 30);

    edit->move(0, 50); edit->resize(250, 20);
    dia->setWindowTitle(title); dia->resize(250, 120);
    dia->show();
}

void SeqWidget::refresh()
{
    widget->clear();
    int* tmp = ptr->Begin();
    int n = ptr->Size();
    for (int i = 0; i < n; i++) {
        widget->addItem(QString::fromStdString(std::to_string(*(tmp + i))));
    }

}

void SeqWidget::connects() {
    connect(btn_creat, &QPushButton::clicked, this, [ = ]() {
        QDialog *dia = new QDialog(this);
        QLabel *lab = new QLabel(dia);
        QPushButton *check = new QPushButton(dia);
        QLineEdit *edit = new QLineEdit(dia);
        setDia(dia, lab, check, edit, "请输入需要创建的序列\n（使用空格相隔）", "创建表");

        connect(check, &QPushButton::clicked, dia, [ = ]() {
            std::string s = edit->text().toStdString();
            std::vector<int> tmp = getnum(s);
            delete ptr;
            ptr = new Seqlist<int>();
            for (int i = 0; i < tmp.size(); i++) ptr->Insert_last(tmp[i]);
            refresh();
            dia->close();
        });
    });

    connect(btn_push, &QPushButton::clicked, this, [ = ]() {
        QDialog *dia = new QDialog(this);
        QLabel *lab = new QLabel(dia);
        QPushButton *check = new QPushButton(dia);
        QLineEdit *edit = new QLineEdit(dia);
        setDia(dia, lab, check, edit, "请输入插入元素的值", "插入元素");

        connect(check, &QPushButton::clicked, dia, [ = ]() {
            std::string s = edit->text().toStdString();
            std::vector<int> tmp = getnum(s);
            if (tmp.size() == 1) {
                ptr->Insert_last(tmp[0]);
                refresh();
                dia->close();
            }
        });
    });

    connect(btn_Ins_multiple, &QPushButton::clicked, this, [ = ]() {
        QDialog *dia = new QDialog(this);
        QLabel *lab = new QLabel(dia);
        QPushButton *check = new QPushButton(dia);
        QLineEdit *edit = new QLineEdit(dia);
        setDia(dia, lab, check, edit, "请输入指定数据X及插入元素值Y\n（用空格隔开）", "在指定数据后插入元素");

        connect(check, &QPushButton::clicked, dia, [ = ]() {
            std::string s = edit->text().toStdString();
            std::vector<int> tmp = getnum(s);
            if (tmp.size() == 2) {
                ptr->Insert(tmp[0], tmp[1], true);		//请检查参数是否适配
                refresh();
                dia->close();
            }
        });
    });

    connect(btn_Ins_wanted, &QPushButton::clicked, this, [ = ]() {
        if (widget->currentRow() == -1) {
            QMessageBox::critical(this, "错误", "未选定元素");
            return;
        }

        QDialog *dia = new QDialog(this);
        QLabel *lab = new QLabel(dia);
        QPushButton *check = new QPushButton(dia);
        QLineEdit *edit = new QLineEdit(dia);
        setDia(dia, lab, check, edit, "请输入插入元素值", "在指定元素后插入元素");

        connect(check, &QPushButton::clicked, dia, [ = ]() {
            std::string s = edit->text().toStdString();
            std::vector<int> tmp = getnum(s);
            if (tmp.size() == 1) {
                ptr->Insert(widget->currentRow(), tmp[0], false);	//请检查参数是否适配
                refresh();
                dia->close();
            }
        });
    });

    connect(btn_Del_wanted, &QPushButton::clicked, this, [ = ]() {
        if (widget->currentRow() == -1) {
            QMessageBox::critical(this, "错误", "未选定元素");
            return;
        }

        ptr->Remove(widget->currentRow(), false);	//请检查参数是否适配
        refresh();
    });

    connect(btn_Del_multiple, &QPushButton::clicked, this, [ = ]() {
        QDialog *dia = new QDialog(this);
        QLabel *lab = new QLabel(dia);
        QPushButton *check = new QPushButton(dia);
        QLineEdit *edit = new QLineEdit(dia);
        setDia(dia, lab, check, edit, "请输入指定删除元素值", "删除所有指定值元素");

        connect(check, &QPushButton::clicked, dia, [ = ]() {
            std::string s = edit->text().toStdString();
            std::vector<int> tmp = getnum(s);
            if (tmp.size() == 1) {
                ptr->Remove(tmp[0], true);	//请检查参数是否适配
                refresh();
                dia->close();
            }
        });
    });

    connect(btn_reverse, &QPushButton::clicked, this, [ = ]() {
        ptr->Reverse();
        refresh();
    });

}

void SeqWidget::Setptr(Seqlist<int> *x) {
    ptr = x;
}
