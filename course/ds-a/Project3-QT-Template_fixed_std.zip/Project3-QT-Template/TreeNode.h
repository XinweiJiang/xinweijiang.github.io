#ifndef TREENODE_H
#define TREENODE_H
#include <string>
#include <QDebug>
class TreeNode {
public:
    TreeNode *f,*l,*r;
    std::string E,C;
    TreeNode():f(nullptr),l(nullptr),r(nullptr),E(""),C("") {}
    TreeNode(TreeNode *_f,TreeNode *_l,TreeNode *_r,std::string _s,std::string _ss):f(_f),l(_l),r(_r),E(_s),C(_ss) {}
    ~TreeNode() {
        delete l;
        delete r;
    }
};

#endif // TREENODE_H
