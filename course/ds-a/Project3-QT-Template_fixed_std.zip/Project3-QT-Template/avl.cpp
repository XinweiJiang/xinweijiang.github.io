  #include "avl.h"
#include <ctime>
#include <algorithm>
AVLNode *AVL::find(string s,AVLNode *T,pair<AVLNode*,AVLNode*> &rst,vector<string>* path)
{
    while (T!=nullptr) {
        if (path!=nullptr) path->push_back(T->E);
        if (s<=T->E) {
            rst.second=T;
            T=T->l;
        }
        else {
            rst.first=T;
            T=T->r;
        }
    }

}

AVLNode *AVL::insert(string s1, string s2)
{

    if (root==nullptr) {
        root=new AVLNode(nullptr,nullptr,nullptr,s1,s2,1,0);
        return root;
    }
    pair<AVLNode*,AVLNode*> rst;
    AVLNode *T;
    find(s1,root,rst);
    if (rst.second==nullptr || rst.second->E!=s1) {
        if (rst.first!=nullptr && rst.first->r==nullptr) T=rst.first,rst.first->r=new AVLNode(rst.first,nullptr,nullptr,s1,s2,1,0);
        else  T=rst.second,rst.second->l=new AVLNode(rst.second,nullptr,nullptr,s1,s2,1,0);
    }
    updata(T);
    T=T->f;
    for (;T!=nullptr;T=T->f) {
        if (T->factor<=-1) {
            RightBlance(T),T=T->f;
        }
        else {
            if (T->factor>=1) {
                LeftBlance(T),T=T->f;
                continue;
            }
        }
    }
    return nullptr;

}

void AVL::Inorder_Traversal(vector<string> *v1, vector<string> *v2, AVLNode *T)
{
    if (v1->size()==10 || T==nullptr) return;
    Inorder_Traversal(v1,v2,T->l);
    if (v1->size()==10 || T==nullptr) return;
    v1->push_back(T->E);v2->push_back(T->C);
    Inorder_Traversal(v1,v2,T->r);
}

void AVL::Rotate_right(AVLNode *T)
{
    AVLNode *l=T->l,*r=T->r;
    if (l==nullptr) return;
    if (T->f!=nullptr) {
        if (T->f->l==T) T->f->l=l; else T->f->r=l;
    }
    else root=l;
    l->f=T->f;
    T->f=l;
    T->l=l->r;
    if (l->r!=nullptr) l->r->f=T;
    l->r=T;
    updata(T);
    updata(l);
    updata(l->f);
}

void AVL::Rotate_left(AVLNode *T)
{
    AVLNode *l=T->l,*r=T->r;
    if (r==nullptr) return;
    if (T->f!=nullptr) {
        if (T->f->l==T) T->f->l=r; else T->f->r=r;
    }
    else root=r;
    r->f=T->f;
    T->f=r;
    T->r=r->l;
    if (r->l!=nullptr) r->l->f=T;
    r->l=T;
    updata(T);
    updata(r);
    updata(r->f);
}

void AVL::updata(AVLNode *T)
{
    if (T==nullptr) return;
    T->height=max((T->l==nullptr)?0:(T->l->height),(T->r==nullptr)?0:(T->r->height))+1;
    T->factor=((T->l==nullptr)?0:(T->l->height))-((T->r==nullptr)?0:(T->r->height));
}

void AVL::RightBlance(AVLNode *T)
{
    AVLNode *r=T->r;
    if (r->factor==1) Rotate_right(r);
    Rotate_left(T);
}

void AVL::LeftBlance(AVLNode *T)
{
    AVLNode *l=T->l;
    if (l->factor==-1) Rotate_left(l);
    Rotate_right(T);
}

//AVLNode *AVL::build(int l, int r,AVLNode *f)
//{
//    if (l>r) return nullptr;
//    int mid=(l+r)>>1;
////    qDebug() << mid;
//    AVLNode *rtn=new AVLNode();
//    rtn->l=build(l,mid-1,rtn);
//    rtn->r=build(mid+1,r,rtn);
//    rtn->E=v_E->at(mid);
//    rtn->C=v_C->at(mid);
//    rtn->f=f;
//    return rtn;
//}

AVLNode *AVL::build(int l, int r,AVLNode *f)
{
    if (l>r) return nullptr;
    int mid=rand()%(r-l+1)+l;
//    int mid=(l+r)>>1;
    insert(v_E->at(mid),v_C->at(mid));
    build(l,mid-1,nullptr);
    build(mid+1,r,nullptr);
//    for (int i=l;i<=r;i++) {
//        insert(v_E->at(i),v_C->at(i));
//    }
    return nullptr;
}

AVL::AVL(vector<string>* v1,vector<string> *v2) {
    v_E=v1;
    v_C=v2;
    root=nullptr;
//    root=build(0,v_E->size()-1,nullptr);
    srand(time(NULL));
    build(0,v_E->size()-1,nullptr);
}

void AVL::Find(string s, vector<string> *v1, vector<string> *v2,vector<string>* path)
{
//    Inorder_Traversal(v1,v2,root);
    pair<AVLNode*,AVLNode*> rst;
    find(s,root,rst,path);
    AVLNode* t=rst.second;
    if (t->E<s) t=t->f;
    while (t!=nullptr) {
        v1->push_back(t->E);v2->push_back(t->C);
        Inorder_Traversal(v1,v2,t->r);
        while ((t->f!=nullptr) && (t->f->r==t)) t=t->f;
        t=t->f;
    }
    while (!v1->empty()) {
        string tmp=v1->back();
        if (tmp.substr(0,s.length())!=s) v1->pop_back(),v2->pop_back(); else break;
    }
}


