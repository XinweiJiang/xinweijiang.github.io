#ifndef AVL_H
#define AVL_H
#include <bits/stdc++.h>
using namespace std;
class AVLNode {
public:
    AVLNode *f,*l,*r;
    std::string E,C;
    int height,factor;
    AVLNode() {}
    AVLNode(AVLNode *_f,AVLNode *_l,AVLNode *_r,std::string _E,std::string _C,int H,int _fa):f(_f),l(_l),r(_r),E(_E),C(_C),height(H),factor(_fa) {}
};
class AVL
{
private:
    AVLNode *find(string s,AVLNode *T,pair<AVLNode*,AVLNode*> &rst,vector<string>* path=nullptr);
    AVLNode *insert(string s1,string s2);
    void Inorder_Traversal(vector<string>* v1,vector<string> *v2,AVLNode *T);
    void Rotate_right(AVLNode *T);
    void Rotate_left(AVLNode *T);
    void updata(AVLNode *T);
    void RightBlance(AVLNode *T);
    void LeftBlance(AVLNode *T);
public:
    AVLNode *root;
    vector<string>* v_E, *v_C;
    AVLNode *build(int l,int r,AVLNode *f);
    AVL(vector<string>* v1,vector<string> *v2);
    void Find(string s,vector<string>* v1,vector<string> *v2,vector<string>* path=nullptr);
};

#endif // AVL_H
