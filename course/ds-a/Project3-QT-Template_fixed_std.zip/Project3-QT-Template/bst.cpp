#include "bst.h"
#include <ctime>
#include <algorithm>

TreeNode *BST::find(string s,TreeNode *T,pair<TreeNode*,TreeNode*> &rst,vector<string> *path)
{
    while (T!=nullptr) {
        if (path!=nullptr) path->push_back(T->E);
        if (s<=T->E) {
            rst.second=T;
            T=T->l;
        }
        else {
            rst.first=T;
            T=T->r;
        }
    }

}

TreeNode *BST::insert(string s1, string s2)
{

    if (root==nullptr) {
        root=new BSTNode(nullptr,nullptr,nullptr,s1,s2);
        return root;
    }
    pair<TreeNode*,TreeNode*> rst;
    find(s1,root,rst);
    if (rst.second==nullptr || rst.second->E!=s1) {
        if (rst.first!=nullptr && rst.first->r==nullptr) rst.first->r=new BSTNode(rst.first,nullptr,nullptr,s1,s2);
        else  rst.second->l=new BSTNode(rst.second,nullptr,nullptr,s1,s2);
    }
    return nullptr;

}

void BST::Inorder_Traversal(vector<string> *v1, vector<string> *v2, TreeNode *T)
{
    if (v1->size()==10 || T==nullptr) return;
    Inorder_Traversal(v1,v2,T->l);
    if (v1->size()==10 || T==nullptr) return;
    v1->push_back(T->E);v2->push_back(T->C);
    Inorder_Traversal(v1,v2,T->r);
}

//BSTNode *BST::build(int l, int r,BSTNode *f)
//{
//    if (l>r) return nullptr;
//    int mid=(l+r)>>1;
////    qDebug() << mid;
//    BSTNode *rtn=new BSTNode();
//    rtn->l=build(l,mid-1,rtn);
//    rtn->r=build(mid+1,r,rtn);
//    rtn->E=v_E->at(mid);
//    rtn->C=v_C->at(mid);
//    rtn->f=f;
//    return rtn;
//}

BSTNode *BST::build(int l, int r,BSTNode *f)
{
    if (l>r) return nullptr;
    int mid=rand()%(r-l+1)+l;
    insert(v_E->at(mid),v_C->at(mid));
    build(l,mid-1,nullptr);
    build(mid+1,r,nullptr);
    return nullptr;
}

BST::BST(vector<string>* v1,vector<string> *v2) {
    v_E=v1;
    v_C=v2;
    root=nullptr;
//    root=build(0,v_E->size()-1,nullptr);
    srand(time(NULL));
    build(0,v_E->size()-1,nullptr);
}

void BST::Find(string s, vector<string> *v1, vector<string> *v2,vector<string>* path)
{
//    Inorder_Traversal(v1,v2,root);
    pair<TreeNode*,TreeNode*> rst;
    find(s,root,rst,path);
    TreeNode* t=rst.second;
    if (t->E<s) t=t->f;
    while (t!=nullptr) {
        v1->push_back(t->E);v2->push_back(t->C);
        Inorder_Traversal(v1,v2,t->r);
        while ((t->f!=nullptr) && (t->f->r==t)) t=t->f;
        t=t->f;
    }
    while (!v1->empty()) {
        string tmp=v1->back();
        if (tmp.substr(0,s.length())!=s) v1->pop_back(),v2->pop_back(); else break;
    }
}


