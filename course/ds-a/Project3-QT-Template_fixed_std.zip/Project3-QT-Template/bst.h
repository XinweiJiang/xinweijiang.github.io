#ifndef BST_H
#define BST_H
#include "TreeNode.h"
#include <vector>
using namespace std;
class BSTNode:public TreeNode {
public:
    BSTNode():TreeNode() {}
    BSTNode(TreeNode *_f,TreeNode *_l,TreeNode *_r,std::string _E,std::string _C):TreeNode(_f,_l,_r,_E,_C) {}
};
class BST
{
private:
    TreeNode *find(string s,TreeNode *T,pair<TreeNode*,TreeNode*> &rst,vector<string>* path=nullptr);
    TreeNode *insert(string s1,string s2);
    void Inorder_Traversal(vector<string>* v1,vector<string> *v2,TreeNode *T);

public:
    BSTNode *root;
    vector<string>* v_E, *v_C;
    BSTNode *build(int l,int r,BSTNode *f);
    BST(vector<string>* v1,vector<string> *v2);
    void Find(string s,vector<string>* v1,vector<string> *v2,vector<string>* path=nullptr);

};

#endif // BST_H
