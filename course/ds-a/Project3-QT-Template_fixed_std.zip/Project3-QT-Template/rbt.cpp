#include "rbt.h"
#include <QDebug>



RBT::RBT():root(nullptr),depth(0){}

RBT::RBT(vector<string> *s1, vector<string> *s2):depth(0)
{
    root=nullptr;
    for (int i=0;i<s1->size();i++) {
        insert(s1->at(i),s2->at(i));
    }
}

void RBT::Rotate_left(RBTNode* x)
{
    RBTNode *y = x->r;
    x->r = y->l;
    if (y->l)
        y->l->f = x;
    y->f = x->f;
    if (x->f == nullptr)
        root = y;
    else {
        if (x->f->l == x) x->f->l = y;else x->f->r = y;
    }
    y->l = x;
    x->f = y;
}

void RBT::Rotate_right(RBTNode* x)
{
    RBTNode* y = x->l;
    x->l = y->r;
    if (y->r)
        y->r->f = x;
    y->f = x->f;
    if (x->f == nullptr)
        root = y;
    else {
        if (x->f->l == x) x->f->l = y; else x->f->r = y;
    }
    y->r = x;
    x->f = y;
}

void RBT::insert(string E,string C)
{
    RBTNode* z = new RBTNode(RED,nullptr,nullptr,nullptr,E,C);
    RBTNode* y = nullptr;
    RBTNode* x = root;
    int cnt=0;
    while (x)
    {
       y=x;
       x=(x->E>=E)?x->l:x->r;
       cnt++;
    }
    depth=max(cnt,depth);
    z->f = y;
    if (y == nullptr)
        root = z;
    else if (E < y->E)
        y->l = z;
    else
        y->r = z;
    insert_fixup(z);
}

void RBT::insert_fixup(RBTNode* z)
{
    while (z->f && z->f->color == RED)
    {
        if (z->f->f->l == z->f)
        {
            RBTNode *y = z->f->f->r;
            if (y && y->color == RED)   //case 1
            {
                z->f->color = BLACK;
                y->color = BLACK;
                z->f->f->color = RED;
                z = z->f->f;
            }
            else
            {
                if (z == z->f->r)   //case 2
                {
                    z = z->f;
                    Rotate_left(z);
                }                       //case 3
                z->f->color = BLACK;
                z->f->f->color = RED;
                Rotate_right(z->f->f);
            }
        }
        else
        {
            RBTNode *y = z->f->f->l;
            if (y && y->color == RED)
            {
                z->f->color = BLACK;
                y->color = BLACK;
                z->f->f->color = RED;
                z = z->f->f;
            }
            else
            {
                if (z == z->f->l)
                {
                    z = z->f;
                    Rotate_right(z);
                }
                z->f->color = BLACK;
                z->f->f->color = RED;
                Rotate_left(z->f->f);
            }
        }
    }
    root->color = BLACK;
}



void RBT::rb_delete(string E)
{
    RBTNode *z = search(root,E);
    RBTNode *x;
    if (z == nullptr)
    {
        return;
    }
    RBTNode *y = z;
    Color original_color = y->color;
    if (z->l == nullptr)
    {
        x = z->r;
        rb_transplant(z, z->r);
    }
    else if (z->r == nullptr)
    {
        x = z->l;
        rb_transplant(z, z->l);
    }
    else
    {
        y = tree_minimun(z->r);
        original_color = y->color;
        x = y->r;
        if (y->f == z)
        {
            if (x)
                x->f = y;
        }
        else
        {
            rb_transplant(y, y->r);
            y->r = z->r;
            y->r->f = y;
        }
        rb_transplant(z, y);
        y->l = z->l;
        y->l->f = y;
        y->color = z->color;
    }
    if (original_color == BLACK)
        rb_delete_fixup(x);
}

void RBT::rb_transplant(RBTNode* u, RBTNode* v)
{
    if (u->f == nullptr)
        root = v;
    else if (u == u->f->l)
        u->f->l = v;
    else
        u->f->r = v;
    if (v)
        v->f = u->f;
}

void RBT::rb_delete_fixup(RBTNode* x)
{
    if (x == nullptr)
        return;
    while (x != root && x->color == BLACK)
    {
        if (x == x->f->l)
        {
            RBTNode* w = x->f->r;
            if (w->color == RED)        //case 1
            {
                w->color = BLACK;
                x->f->color = RED;
                Rotate_left(x->f);
                w = x->f->r;
            }
            if (w->l->color == BLACK && w->r->color == BLACK) //case 2
            {
                w->color = RED;
                x = x->f;
            }
            else
            {
                if (w->r->color == BLACK)   //case 3
                {
                    w->l->color = BLACK;
                    w->color = RED;
                    Rotate_right(w);
                    w = x->f->r;
                }
                w->color = x->f->color;         //case 4
                x->f->color = BLACK;
                w->r->color = BLACK;
                Rotate_left(x->f);
                x = root;
            }
        }
        else
        {
            RBTNode* w = x->f->l;
            if (w->color == RED)
            {
                w->color = BLACK;
                x->f->color = RED;
                Rotate_right(x->f);
                w = x->f->l;
            }
            if (w->r->color == BLACK && w->l->color == BLACK)
            {
                w->color = RED;
                x = x->f;
            }
            else
            {
                if (w->l->color == BLACK)
                {
                    w->r->color = BLACK;
                    w->color = RED;
                    Rotate_left(w);
                    w = x->f->l;
                }
                w->color = x->f->color;
                x->f->color = BLACK;
                w->l->color = BLACK;
                Rotate_right(x->f);
                x = root;
            }
        }
    }
    x->color = BLACK;
}


RBTNode *RBT::find(string s, RBTNode *T, pair<RBTNode *, RBTNode *> &rst,vector<string>* path)
{
    while (T!=nullptr) {
        if (path!=nullptr) path->push_back(T->E);
        if (s<=T->E) {
            rst.second=T;
            T=T->l;
        }
        else {
            rst.first=T;
            T=T->r;
        }
    }
}

void RBT::Find(string s, vector<string> *v1, vector<string> *v2,vector<string>* path)
{
    pair<RBTNode*,RBTNode*> rst;
    find(s,root,rst,path);
    RBTNode* t=rst.second;
    if (t->E<s) t=t->f;
    while (t!=nullptr) {
        v1->push_back(t->E);v2->push_back(t->C);
        Inorder_Traversal(v1,v2,t->r);
        while ((t->f!=nullptr) && (t->f->r==t)) t=t->f;
        t=t->f;
    }
    while (!v1->empty()) {
        string tmp=v1->back();
        if (tmp.substr(0,s.length())!=s) v1->pop_back(),v2->pop_back(); else break;
    }
}

void RBT::Inorder_Traversal(vector<string> *v1, vector<string> *v2, RBTNode *T)
{
    if (v1->size()==10 || T==nullptr) return;
    Inorder_Traversal(v1,v2,T->l);
    if (v1->size()==10 || T==nullptr) return;
    v1->push_back(T->E);v2->push_back(T->C);
    Inorder_Traversal(v1,v2,T->r);
}

RBTNode* RBT::search(RBTNode* T, string E)
{
    while (T!=nullptr && T->E!=E) {
        T=(T->E>E)?T->l:T->r;
    }
    return T;
}

RBTNode* RBT::tree_minimun(RBTNode* T)
{
    while (T && T->l) T = T->l;
    return T;
}
