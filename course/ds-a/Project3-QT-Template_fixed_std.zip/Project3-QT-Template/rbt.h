#ifndef RBT_H
#define RBT_H

#include <bits/stdc++.h>

using namespace std;

enum Color {RED, BLACK};

struct RBTNode
{
    Color color;
    RBTNode *f,*l, *r;
    string E,C;
    RBTNode(string _key = 0) :color(RED), E(_key) , C(""), l(nullptr), r(nullptr), f(nullptr) {}
    RBTNode(Color c,RBTNode *_f,RBTNode *_l,RBTNode *_r,string _E,string _C):color(c),f(_f),l(_l),r(_r),E(_E),C(_C) {}
};

class RBT
{
public:
    RBT();
    RBT(vector<string> *s1, vector<string> *s2);
    void insert(string E,string C);
    void rb_delete(string key);
    RBTNode* search(string E);
    int depth;
    RBTNode *find(string s,RBTNode *T,pair<RBTNode*,RBTNode*> &rst,vector<string>* path=nullptr);
    void Find(string s,vector<string>* v1,vector<string> *v2,vector<string>* path=nullptr);
    void Inorder_Traversal(vector<string>* v1,vector<string> *v2,RBTNode *T);
private:
    RBTNode *root;
    void insert_fixup(RBTNode* z);
    void Rotate_left(RBTNode* x);
    void Rotate_right(RBTNode* x);
    void rb_transplant(RBTNode* u, RBTNode* v);
    void rb_delete_fixup(RBTNode* x);
    RBTNode* search(RBTNode* T, string E);
    RBTNode* tree_minimun(RBTNode* T);
};

#endif // RBT_H
