#include "tire.h"

Tire::Tire(std::vector<std::string> *v1, std::vector<std::string> *v2)
{
    root=new TireNode();
    for (int i=0;i<v1->size();i++) {
        insert(v1->at(i),v2->at(i));
    }
}

