#ifndef TIRE_H
#define TIRE_H
#include <string>
#include <vector>
class TireNode{
public:
    TireNode* son[256];
    std::string C;
    TireNode() {
        for (int i=0;i<256;i++) son[i]=nullptr;
        C="";
    }
};

class Tire
{
public:
    TireNode *root;
    void insert(std::string s,std::string s1) {
        if (s.empty()) return;
        TireNode *T=root;
        for (auto i:s) {
            if (T->son[i]==nullptr) T->son[i]=new TireNode();
            T=T->son[i];
        }
        if (T==root) return;
        T->C=s1;
    }
    void Traval(TireNode *T,std::string *s, std::vector<std::string> *v1, std::vector<std::string> *v2,std::vector<std::string>* path=nullptr) {
        if (T==nullptr || v1->size()==10) return;
        if (!T->C.empty())  v1->push_back(*s),v2->push_back(T->C);
        for (int i=0;i<256;i++) {
            if (T->son[i]!=nullptr) {
                s->push_back(i);
                Traval(T->son[i],s,v1,v2,path);
                s->pop_back();
            }
        }
    }
    void Find(std::string s, std::vector<std::string> *v1, std::vector<std::string> *v2,std::vector<std::string>* path=nullptr) {
        for (auto i:s) {
            if (s.empty()) return;
            TireNode *T=root;
            std::string tmp;
            for (auto i:s) {
                T=T->son[i];
                if (T==nullptr) break; else tmp+=i;
            }
            if (T==root) return;
            Traval(T,&tmp,v1,v2,path);
        }
    }
    Tire():root(new TireNode) {}
    Tire(std::vector<std::string> *v1,std::vector<std::string> *v2);

};

#endif // TIRE_H
