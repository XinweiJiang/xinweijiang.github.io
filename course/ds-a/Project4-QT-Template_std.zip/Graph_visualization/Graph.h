#ifndef GRAPH_H
#define GRAPH_H
class Edge {
public:;
    int dst;
    int dis;
    Edge* nxt;
    Edge(int _dst=0,int _dis=0,Edge* _nxt=nullptr):dst(_dst),dis(_dis),nxt(_nxt) {}
};

class Node {
public:
    int num;
    Edge* last;
    Node(int _num=0,Edge* _last=nullptr):num(_num),last(_last) {}
};

#endif // GRAPH_H
