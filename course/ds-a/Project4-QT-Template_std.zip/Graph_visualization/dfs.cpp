#include "dfs.h"
void EdgeLink(Node *a,Node *b,int dis) {
    a->last=new Edge(b->num,dis,a->last);
}

DFS::DFS(string s)
{
    vector<int> v=getnum(s);
    node=new vector<Node*>();
    int n=v[0];
    vis=new vector<bool>(n+1);
    for (int i=0;i<=n;i++) {
        node->push_back(new Node(i));
    }
    EdgeLink(node->at(n),node->at(0),0);
    for (auto i=v.begin()+1;(i+2)<v.end();i+=3) {
        int s=(*i),t=*(i+1),dis=*(i+2);
        EdgeLink(node->at(s),node->at(t),dis);
        EdgeLink(node->at(t),node->at(s),dis);
    }
    steps="";
    for (int i=0;i<n;i++) {
        vis->at(i)=0;
    }
    vis->at(0)=1;
    dfs(node->at(0),nullptr);
}

void DFS::dfs(Node* cur,Node* f)
{
    int cnt=0;
    string s="",s_R="";
//    if (f!=nullptr)
//    for (Edge* ptr=f->last;ptr!=nullptr;ptr=ptr->nxt) {
//        if (!vis->at(ptr->dst)) {
//            cnt++;
//            s+=to_string(f->num)+" "+to_string(ptr->dst)+" 1 ";
//        }
//    }
    for (Edge* ptr=cur->last;ptr!=nullptr;ptr=ptr->nxt) {
        if (!vis->at(ptr->dst)) {
            string s1="",s2="";
            int cnt1=0;
            for (Edge* ptr1=ptr;ptr1!=nullptr;ptr1=ptr1->nxt) {
                if (!vis->at(ptr1->dst)) {
                    cnt1++;
                    s1+=to_string(cur->num)+" "+to_string(ptr1->dst)+" 3 ";
                    s2+=to_string(cur->num)+" "+to_string(ptr1->dst)+" 1 ";
                }
            }
            steps+=to_string(cnt+cnt1)+" "+s+s1;
            steps+=to_string(cnt1+1)+" "+s2+to_string(cur->num)+" "+to_string(ptr->dst)+" 2 ";
            vis->at(ptr->dst)=1;
            dfs(node->at(ptr->dst),cur);
        }
    }
}
