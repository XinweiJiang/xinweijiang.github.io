#ifndef DFS_H
#define DFS_H
#include <bits/stdc++.h>
#include "Graph.h"
using namespace std;

class DFS
{
public:
    DFS(string);

    string steps;
    vector<bool> *vis;
    vector<Node*> *node;
    std::vector<int> getnum(std::string s) {
        int x = 0;
        std::vector<int> v;
        for (int i = 0; i < s.length(); i++) {
            if (s[i] >= '0' && s[i] <= '9') {
                while (s[i] >= '0' && s[i] <= '9' && i < s.length()) x = x * 10 + s[i] - '0', i++;
                v.push_back(x);
                x = 0;
            }
        }
        return v;
    }
    void dfs(Node*,Node*);
    string Steps() {
        return steps;
    }
};

#endif // DFS_H
