#pragma once
#pragma comment(lib,"dinput8.lib")
#pragma comment(lib,"dxguid.lib")
#pragma comment(lib,"d2d1.lib")
#pragma comment(lib, "Windowscodecs.lib" )
#include<cmath>
#include<dinput.h>
#include<windows.h>
#include<d2d1.h>
#include<D2d1helper.h>
#include<wincodec.h>
#include<vector>
#include<sstream>
#include<random>
#include<stack>
//�������ҵ���gametimer
class GameTimer
{
public:
	GameTimer() :mSecondsPerCount(0.0), mDeltaTime(-1.0), mBaseTime(0),
		mPausedTime(0), mPrevTime(0), mCurrTime(0), mStopped(false)
	{
		__int64 countsPerSec;
		QueryPerformanceFrequency((LARGE_INTEGER*)&countsPerSec);
		mSecondsPerCount = 1.0 / (double)countsPerSec;
	};
	~GameTimer() {};
	float GameTime()const;//in seconds
	float DeltaTime()const//in seconds
	{
		return (float)mDeltaTime;
	}
	void Reset()//����Ϣѭ��֮ǰ����
	{
		__int64 currtime;
		QueryPerformanceCounter((LARGE_INTEGER*)&currtime);
		mBaseTime = currtime;
		mPrevTime = currtime;
		mStopTime = 0;
		mStopped = false;
	}
	void Tick() //ÿ��֡����һ��
	{
		if (mStopped)
		{
			mDeltaTime = 0.0;
			return;
		}
		__int64	currTime;
		QueryPerformanceCounter((LARGE_INTEGER*)&currTime);
		mCurrTime = currTime;
		//������ʱ��
		mDeltaTime = (mCurrTime - mPrevTime) * mSecondsPerCount;
		//Ϊ��һ�μ�����׼��
		mPrevTime = mCurrTime;
		if (mDeltaTime < 0.0)
		{
			mDeltaTime = 0.0;
		}
	}
	float TotalTime()const
	{
		// If we are stopped, do not count the time that has passed since we stopped.
		// Moreover, if we previously already had a pause, the distance 
		// mStopTime - mBaseTime includes paused time, which we do not want to count.
		// To correct this, we can subtract the paused time from mStopTime:  
		//
		//                     |<--paused time-->|
		// ----*---------------*-----------------*------------*------------*------> time
		//  mBaseTime       mStopTime        startTime     mStopTime    mCurrTime

		if (mStopped)
		{
			return (float)(((mStopTime - mPausedTime) - mBaseTime) * mSecondsPerCount);
		}

		// The distance mCurrTime - mBaseTime includes paused time,
		// which we do not want to count.  To correct this, we can subtract 
		// the paused time from mCurrTime:  
		//
		//  (mCurrTime - mPausedTime) - mBaseTime 
		//
		//                     |<--paused time-->|
		// ----*---------------*-----------------*------------*------> time
		//  mBaseTime       mStopTime        startTime     mCurrTime

		else
		{
			return (float)(((mCurrTime - mPausedTime) - mBaseTime) * mSecondsPerCount);
		}
	}
	void Start()//ȡ����ͣʱ����
	{
		__int64 startTime;
		QueryPerformanceCounter((LARGE_INTEGER*)&startTime);


		// Accumulate the time elapsed between stop and start pairs.
		//
		//                     |<-------d------->|
		// ----*---------------*-----------------*------------> time
		//  mBaseTime       mStopTime        startTime     

		if (mStopped)
		{
			mPausedTime += (startTime - mStopTime);

			mPrevTime = startTime;
			mStopTime = 0;
			mStopped = false;
		}
	}
	void Stop()//��ͣʱ����
	{
		if (!mStopped)
		{
			__int64 currTime;
			QueryPerformanceCounter((LARGE_INTEGER*)&currTime);

			mStopTime = currTime;
			mStopped = true;
		}
	}
private:
	double mSecondsPerCount;
	double mDeltaTime;
	__int64 mBaseTime;
	__int64 mPausedTime;
	__int64 mStopTime;
	__int64 mPrevTime;
	__int64 mCurrTime;
	bool mStopped;
};